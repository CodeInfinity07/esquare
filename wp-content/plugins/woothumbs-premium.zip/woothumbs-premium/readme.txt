=== WooThumbs - Awesome Product Imagery ===
Contributors: iconicwp
Requires at least: 4.7.4
Tested up to: 6.0
Stable tag: trunk